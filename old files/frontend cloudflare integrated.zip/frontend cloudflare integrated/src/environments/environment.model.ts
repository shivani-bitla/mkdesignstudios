// src/environments/environment.model.ts
export interface Environment {
  production: boolean;
  apiUrl: string;
}