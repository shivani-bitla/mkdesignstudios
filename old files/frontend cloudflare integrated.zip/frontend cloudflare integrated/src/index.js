import { getAssetFromKV, mapRequestToAsset } from '@cloudflare/kv-asset-handler';

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    console.log(`Request: ${url.pathname}`);
    
    try {
      // Custom handler for Angular routes
      if (!url.pathname.includes('.') && !url.pathname.startsWith('/assets/')) {
        const indexRequest = new Request(new URL('/index.html', url), request);
        const response = await getAssetFromKV({
          request: indexRequest,
          waitUntil: ctx.waitUntil.bind(ctx),
        }, {
          ASSET_NAMESPACE: env.__STATIC_CONTENT,
          ASSET_MANIFEST: env.__STATIC_CONTENT_MANIFEST,
        });
        return new Response(response.body, { ...response, status: 200 });
      }
      
      // Default asset handling
      const response = await getAssetFromKV({
        request,
        waitUntil: ctx.waitUntil.bind(ctx),
      }, {
        ASSET_NAMESPACE: env.__STATIC_CONTENT,
        ASSET_MANIFEST: env.__STATIC_CONTENT_MANIFEST,
      });
      
      return response;
      
    } catch (e) {
      console.error(`Error: ${e.message}`);
      
      // Try to serve index.html for all errors (including 404)
      try {
        const indexRequest = new Request(new URL('/index.html', url), request);
        const response = await getAssetFromKV({
          request: indexRequest,
          waitUntil: ctx.waitUntil.bind(ctx),
        }, {
          ASSET_NAMESPACE: env.__STATIC_CONTENT,
          ASSET_MANIFEST: env.__STATIC_CONTENT_MANIFEST,
        });
        return new Response(response.body, { ...response, status: 200 });
      } catch (e2) {
        return new Response(`Internal Error: ${e2.message}`, { status: 500 });
      }
    }
  }
};