import { Component } from '@angular/core';

@Component({
  selector: 'app-home-gallery',
  imports: [],
  templateUrl: './home-gallery.component.html',
  styleUrl: './home-gallery.component.css'
})
export class HomeGalleryComponent {

}
